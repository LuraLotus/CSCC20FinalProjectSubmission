/**
*		Hospital Billing System
*			is a simple hospital billing system developed
*			for the final output of CSCC20 and CC14
*		@author DJ Renzo Emmanuel I. Bince,  Eann Marten E. Lao
*		@version 1.0
*		@since 2019-10-4
*/
public class main{
	public static void main(String args[])throws Exception{
		Login login = new Login();
		login.access();
	}
}

/**
*	This is the Staff class, the parent class for the three menu classes
*	they inherit the methods below, which are present in each account
*/
public class Staff{
	Database db = new Database();
	/**
	*	Allows staff to view the patient details
	*/
	public void viewPatientDetails()throws Exception{
		db.viewPatientDetails();
	}
}
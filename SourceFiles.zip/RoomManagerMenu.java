/**
*	This is the Room Manager Menu class, the menu for Room Manager account
*/
import java.util.Scanner;
public class RoomManagerMenu extends Staff{
	Scanner scanner = new Scanner(System.in);
	/**
	*	Room Manager's menu
	*/
	public void Menu()throws Exception{
		Database db = new Database();
		int choice;
		boolean exit = false;
		while(!exit){
		System.out.println("Good day Room Manager!");
		System.out.println("What would you like to do?");
		System.out.println("1 - View Patient Details");
		System.out.println("2 - Assign Room");
		System.out.println("3 - Exit ");
		choice = scanner.nextInt();
		switch(choice){
			case 1:
				db.viewPatientDetails();
			break;
			case 2:
				db.assignRoom();
			break;
			case 3:
				exit = true;
			break;
		}
		}
	}
}
